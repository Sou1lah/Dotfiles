~/.config/nvim/
├── init.lua
├── keymaps.lua
├── plugins.lua
└── settings.lua