- [ ] new task added
- [x] start leetcode problem(use paper and pen)
- [x] basic operation

---
>  
