# Custom_config
This can be used as a custom NvChad config.

